# Data notes (template)

This repository does **not** redistribute restricted or controlled-access datasets.
Users must obtain the underlying summary statistics from the original providers.

## Expected minimal columns
### Exposure (QTL) tables
You must map your column names to the expected fields in `R/01_ingest_exposure.R` via `colmap`:
- SNP
- beta
- se
- effect_allele
- other_allele
- eaf
- pval
- sample size
- phenotype (gene/protein identifier)

### Outcome (GWAS) tables
Either:
- use OpenGWAS IDs (recommended for reproducibility), or
- implement a local outcome reader in `R/04_extract_outcomes.R`.

## Recommended practice
- Keep raw data in `data/raw/` and **gitignore** it.
- Store derived intermediate files in `outputs/` and **gitignore** it.
