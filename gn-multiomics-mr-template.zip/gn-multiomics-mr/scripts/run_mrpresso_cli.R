#!/usr/bin/env Rscript
suppressPackageStartupMessages({
  library(optparse)
  library(data.table)
  library(MRPRESSO)
})

option_list <- list(
  make_option(c("-i","--infile"), type="character", default=NULL,
              help="RData containing dat_eqtl_min/dat_pqtl_min (user prepared)"),
  make_option(c("-t","--tag"), type="character", default="eQTL",
              help="eQTL or pQTL"),
  make_option(c("-n","--nbdist"), type="integer", default=1000,
              help="NbDistribution"),
  make_option(c("-a","--alpha"), type="double", default=0.05,
              help="SignifThreshold"),
  make_option(c("-o","--outdir"), type="character", default="outputs/mrpresso_run",
              help="Output directory")
)
opt <- parse_args(OptionParser(option_list=option_list))

if (is.null(opt$infile) || !file.exists(opt$infile)) stop("Invalid --infile")
dir.create(opt$outdir, recursive=TRUE, showWarnings=FALSE)

load(opt$infile)
dat_all <- switch(opt$tag,
                  "eQTL" = get0("dat_eqtl_min", ifnotfound=NULL),
                  "pQTL" = get0("dat_pqtl_min", ifnotfound=NULL),
                  NULL)
if (is.null(dat_all)) stop("No dat object found for tag=", opt$tag)

dat_all <- as.data.table(dat_all)
setkey(dat_all, exposure, outcome)

run_one <- function(d) {
  d <- as.data.frame(d)
  d <- d[complete.cases(d[,c("beta.exposure","beta.outcome","se.exposure","se.outcome")]), ]
  if (nrow(d) < 4) return(NULL)
  tryCatch({
    mr_presso(
      BetaOutcome="beta.outcome", BetaExposure="beta.exposure",
      SdOutcome="se.outcome", SdExposure="se.exposure",
      OUTLIERtest=TRUE, DISTORTIONtest=TRUE,
      data=d, NbDistribution=opt$nbdist, SignifThreshold=opt$alpha
    )
  }, error=function(e) NULL)
}

pairs <- unique(dat_all[,.(exposure, outcome)])
global_out <- list(); main_out <- list(); outl_out <- list()

for (i in seq_len(nrow(pairs))) {
  ex <- pairs$exposure[i]; ou <- pairs$outcome[i]
  d  <- dat_all[.(ex, ou)]
  res <- run_one(d)
  if (is.null(res)) next

  g <- res$`MR-PRESSO results`$`Global Test`
  global_out[[length(global_out)+1]] <- data.table(exposure=ex, outcome=ou,
                                                   RSSobs=as.numeric(g$RSSobs),
                                                   P=as.numeric(g$Pvalue))
  m <- as.data.table(res$`Main MR results`)
  m[, `:=`(exposure=ex, outcome=ou)]
  main_out[[length(main_out)+1]] <- m

  o <- res$`MR-PRESSO results`$`Outlier Test`
  if (!is.null(o) && nrow(o)>0) {
    o <- as.data.table(o); o[, `:=`(exposure=ex, outcome=ou)]
    outl_out[[length(outl_out)+1]] <- o
  }
}

fwrite(rbindlist(global_out, fill=TRUE), file.path(opt$outdir, "MRPRESSO_Global.csv"))
fwrite(rbindlist(main_out,   fill=TRUE), file.path(opt$outdir, "MRPRESSO_Main.csv"))
if (length(outl_out)>0) fwrite(rbindlist(outl_out, fill=TRUE), file.path(opt$outdir, "MRPRESSO_Outliers.csv"))

message("Done: ", opt$outdir)
