#!/usr/bin/env Rscript
suppressPackageStartupMessages({
  library(data.table)
})

args <- commandArgs(trailingOnly = TRUE)
cfg_path <- ifelse(length(args) >= 1, args[1], "config/config_example.yml")

source("R/00_setup.R")
source("R/01_ingest_exposure.R")
source("R/02_instrument_filter.R")
source("R/03_ld_clump_local.R")
source("R/04_extract_outcomes.R")
source("R/05_harmonise.R")
source("R/06_run_mr_core.R")
source("R/07_sensitivity.R")

cfg <- read_config(cfg_path)
setup_env(cfg)

dir.create(cfg$outdir, recursive=TRUE, showWarnings=FALSE)

colmaps <- get_default_colmaps()

# Exposure ingestion (users must edit config + colmaps)
exp_pqtl <- read_exposure_generic(cfg$exposure_files$pqtl, colmaps$pqtl, sep="\t", exposure_label="_pQTL")
exp_eqtl <- read_exposure_generic(cfg$exposure_files$eqtl, colmaps$eqtl, sep="\t", exposure_label="_eQTL")

exp_all <- rbindlist(list(exp_pqtl, exp_eqtl), fill=TRUE)

# Instrument filtering (contains intentional stub)
exp_iv <- filter_instruments(exp_all, cfg)

# LD clumping
exp_clumped <- ld_clump_by_exposure(exp_iv, cfg)

# Outcome extraction (OpenGWAS route shown)
outcome_id <- cfg$outcome_ids_primary[[1]]
out_dat <- extract_outcome_opengwas(snps = exp_clumped$SNP, outcome_id = outcome_id)

# Harmonise + QC (contains intentional stub)
dat <- harmonise_and_qc(exp_clumped, out_dat, cfg)

# MR core
mr_res <- run_mr_batch(dat)

fwrite(as.data.table(mr_res), file.path(cfg$outdir, "MR_results.csv"))
message("Finished (partial template). Outputs: ", cfg$outdir)
