suppressPackageStartupMessages({
  library(TwoSampleMR)
})

extract_outcome_opengwas <- function(snps, outcome_id) {
  TwoSampleMR::extract_outcome_data(snps = snps, outcomes = outcome_id)
}

read_outcome_local <- function(file, colmap, sep="\t") {
  stop("read_outcome_local(): implement local GWAS reader for your file format.")
}
