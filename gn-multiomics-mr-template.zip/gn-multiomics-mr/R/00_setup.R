suppressPackageStartupMessages({
  library(yaml)
})

`%||%` <- function(x, y) if (is.null(x)) y else x

read_config <- function(path) {
  if (!file.exists(path)) stop("Config file not found: ", path)
  cfg <- yaml::read_yaml(path)
  if (is.null(cfg$opengwas_jwt) || grepl("PLEASE_SET", cfg$opengwas_jwt)) {
    stop("Please set opengwas_jwt in config (do NOT commit secrets).")
  }
  cfg
}

setup_env <- function(cfg) {
  Sys.setenv(OPENGWAS_JWT = cfg$opengwas_jwt)
  set.seed(cfg$seed %||% 1)

  if (!file.exists(cfg$plink_bin)) stop("plink not found: ", cfg$plink_bin)
  if (!file.exists(paste0(cfg$ld_ref_bfile, ".bed"))) {
    stop("LD reference bfile not found: ", cfg$ld_ref_bfile, "(.bed/.bim/.fam)")
  }
  invisible(TRUE)
}
