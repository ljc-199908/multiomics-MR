suppressPackageStartupMessages({
  library(TwoSampleMR)
})

harmonise_and_qc <- function(exposure_dat, outcome_dat, cfg) {
  dat <- TwoSampleMR::harmonise_data(exposure_dat, outcome_dat)
  if (isTRUE(cfg$remove_palindromic_ambiguous)) {
    dat <- dat[dat$mr_keep == TRUE, ]
  }
  dat <- steiger_filter_stub(dat)
  dat
}

steiger_filter_stub <- function(dat) {
  stop("steiger_filter_stub(): decide trait types/sample sizes and implement Steiger filtering if needed.")
}
