suppressPackageStartupMessages({
  library(data.table)
})

calc_F_stat <- function(beta, se) (beta^2) / (se^2)

filter_instruments <- function(exposure_dat, cfg) {
  dt <- as.data.table(exposure_dat)

  # P threshold
  dt <- dt[pval.exposure < cfg$p_threshold]

  # F-stat threshold
  dt[, F := calc_F_stat(beta.exposure, se.exposure)]
  dt <- dt[F >= cfg$min_F]

  # Study-specific confounder filtering (left as stub intentionally)
  dt <- phenoscanner_filter_stub(dt, p_cutoff = cfg$phenoscanner_p)

  dt[]
}

phenoscanner_filter_stub <- function(dt, p_cutoff=1e-5) {
  stop("phenoscanner_filter_stub(): implement study-specific confounder filtering (e.g., PhenoScanner).")
}
