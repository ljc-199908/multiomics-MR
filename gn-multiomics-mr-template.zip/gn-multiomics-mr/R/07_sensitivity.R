suppressPackageStartupMessages({
  library(TwoSampleMR)
})

run_sensitivity <- function(dat) {
  n_snps <- sum(dat$mr_keep)
  hetero <- if (n_snps >= 2) TwoSampleMR::mr_heterogeneity(dat) else NULL
  pleio  <- if (n_snps >= 3) TwoSampleMR::mr_pleiotropy_test(dat) else NULL
  ssnp   <- if (n_snps >= 2) TwoSampleMR::mr_singlesnp(dat) else NULL
  loo    <- if (n_snps >= 3) TwoSampleMR::mr_leaveoneout(dat) else NULL
  list(heterogeneity=hetero, pleiotropy=pleio, singlesnp=ssnp, leaveoneout=loo)
}
